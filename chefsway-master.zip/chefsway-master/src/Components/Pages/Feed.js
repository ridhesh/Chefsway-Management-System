//create post
//search bar
//view feed
//navbar: mypost feed profile

import React from 'react';
import { Container } from 'react-bootstrap';
import './Feed.css';

function Feed(props) {
    return (
        <Container className='feed-container' >
            add content inside this feed container
        </Container>
    );
}

export default Feed;