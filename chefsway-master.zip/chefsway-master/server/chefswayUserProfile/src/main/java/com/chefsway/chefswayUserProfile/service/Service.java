//package com.chefsway.chefswayUserProfile.service;
//
//import org.springframework.beans.factory.annotation.Autowired;
//
//import com.chefsway.chefswayUserProfile.model.User;
//import com.chefsway.chefswayUserProfile.repository.UserRepository;
//
//@org.springframework.stereotype.Service
//public class Service {
//	
//	@Autowired
//	private UserRepository userRepository;
//	
//	public User createUser(User newUser) {
//		return userRepository.save(newUser);
//	}
//
//}
