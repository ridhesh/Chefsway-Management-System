package com.chefsway.chefswayUserProfile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChefswayUserProfileApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChefswayUserProfileApplication.class, args);
	}

}
